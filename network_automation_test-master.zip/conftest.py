import pytest
from base.get_driver import GetDriver
import allure

@pytest.fixture(scope="session")
def driver():
    """需确保驱动路径与run_main.py中的测试目录匹配"""
    driver = GetDriver().get_driver()
    yield driver
    driver.quit()

@pytest.fixture(autouse=True)
def attach_screenshot_on_failure(request, driver):
    """需与pytest_args中的--alluredir路径协调"""
    yield
    if request.node.rep_call.failed:
        allure.attach(
            driver.get_screenshot_as_png(),
            name="失败截图",
            attachment_type=allure.attachment_type.PNG
        )