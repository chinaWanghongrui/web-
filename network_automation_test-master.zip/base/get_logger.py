import logging.handlers

class GetLogger:
    logger = None# 类变量，存储唯一的日志器实例

    @classmethod
    def get_logger(cls):
        if cls.logger is None:# 首次调用时初始化
            #获取日志器
            cls.logger = logging.getLogger() # 创建根日志器
            #设置日志级别
            cls.logger.setLevel(logging.INFO)# 仅记录 INFO及以上级别（WARNING, ERROR, CRITICAL）
            #获取处理器 文件-时间分割
            th = logging.handlers.TimedRotatingFileHandler(
                filename="../log/log.log",  # 日志文件路径
                when="m",  # 分割单位：分钟
                interval=1,  # 间隔1分钟
                backupCount=3,  # 保留3份历史日志
                encoding="utf-8"  # 文件编码
            )
            # 设置格式器
            fmt = "%(asctime)s %(levelname)s [%(name)s] [%(filename)s (%(funcName)s:%(lineno)d] - %(message)s"
            fm = logging.Formatter(fmt)
            th.setFormatter(fm)
            cls.logger.addHandler(th)

        return cls.logger