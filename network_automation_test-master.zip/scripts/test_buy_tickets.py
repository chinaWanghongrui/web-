import unittest
from parameterized import parameterized
import allure  # 新增导入
from page import page_login
from page.page_buy_tickets import BuyLogin
from base.get_driver import GetDriver
from page.page_login import PageLogin
from tools.read_json import read_json
from time import sleep

global_var_test_buy_tickets = 0

def get_data_login():
    data = read_json("buy_tickets.json")
    return [(d['start_station'], d['arrive_station'], d['time'],
             d['name'], d['boardcard'], d['phone'],
             d['success'], d['except_result']) for d in data.values()]

class Test_Buy_Tickets(unittest.TestCase):
    driver = None

    @classmethod
    def setUpClass(cls):
        cls.driver = GetDriver().get_driver()
        cls.buy_tickets = BuyLogin(cls.driver)
        cls.login = PageLogin(cls.driver)

    @classmethod
    def tearDownClass(cls):
        page_login.global_variable_login = 0
        GetDriver.quit_driver()

    @allure.title("购票流程测试 - {name} (从{start_station}到{arrive_station})")  # 动态标题
    @allure.story("票务核心功能")
    @parameterized.expand(get_data_login())
    def test_buy_tickets(self, start_station, arrive_station, time, name,
                        boardcard, phone, success=None, expect_result=None):
        global global_var_test_buy_tickets

        with allure.step("1. 用户登录"):
            if global_var_test_buy_tickets == 0:
                self.login.page_login("19132057244", "A984005488", self.driver)
                global_var_test_buy_tickets = 1
                allure.attach(
                    self.driver.get_screenshot_as_png(),
                    name="登录成功截图",
                    attachment_type=allure.attachment_type.PNG
                )

        with allure.step(f"2. 购票操作（乘客：{name}）"):
            self.buy_tickets.page_buy_tickets(start_station, arrive_station,
                                           time, name, boardcard, phone)

        if success:
            with allure.step("3. 验证购票成功"):
                try:
                    self.assertTrue(self.buy_tickets.page_submit_access)
                    for _ in range(3):
                        self.driver.back()
                    self.assertTrue(self.buy_tickets.page_buy_is_logout_success)
                except Exception as e:
                    allure.attach(
                        self.driver.get_screenshot_as_png(),
                        name="购票失败截图",
                        attachment_type=allure.attachment_type.PNG
                    )
                    raise
        else:
            with allure.step("3. 验证错误提示"):
                msg = self.buy_tickets.page_buy_get_error_info()
                try:
                    self.assertEqual(msg, expect_result)
                    sleep(1)
                    self.buy_tickets.page_buy_click_button_OK()
                    for _ in range(3):
                        self.driver.back()
                    self.assertTrue(self.buy_tickets.page_buy_is_logout_success)
                except AssertionError as e:
                    allure.attach(
                        self.driver.get_screenshot_as_png(),
                        name="错误提示不匹配截图",
                        attachment_type=allure.attachment_type.PNG
                    )
                    raise