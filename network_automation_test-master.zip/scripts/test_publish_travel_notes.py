import unittest
from parameterized import parameterized
import allure  # 新增导入
from page import page_login
from page.page_login import PageLogin
from base.get_driver import GetDriver
from page.page_publish_travel_notes import PagePublish
from tools.read_json import read_json

global_var_test_publish = 0

def get_data_publish():
    datas = read_json("publish_travel_notes.json")
    return [(d['name'], d['title'], d['content'], d['success'], d['except_result'])
            for d in datas.values()]

class Test_Publish(unittest.TestCase):
    driver = None

    @classmethod
    @allure.step("初始化测试环境")
    def setUpClass(cls):
        cls.driver = GetDriver().get_driver()
        cls.login = PageLogin(cls.driver)
        cls.publish = PagePublish(cls.driver)

    @classmethod
    def tearDownClass(cls):
        page_login.global_variable_login = 0
        GetDriver.quit_driver()

    @allure.title("游记发布测试 - {title} (作者: {name})")
    @allure.story("内容管理模块")
    @parameterized.expand(get_data_publish())
    def test_publish(self, name, title, content, success=None, except_result=None):
        global global_var_test_publish

        with allure.step("1. 用户登录"):
            if global_var_test_publish == 0:
                self.login.page_login("19132057244", "A984005488", self.driver)
                global_var_test_publish = 1
                allure.attach(
                    self.driver.get_screenshot_as_png(),
                    name="登录状态截图",
                    attachment_type=allure.attachment_type.PNG
                )

        with allure.step(f"2. 发布游记《{title}》"):
            self.publish.page_publish(name, title, content)
            allure.attach(
                content,  # 将游记内容作为文本附件
                name="游记正文内容",
                attachment_type=allure.attachment_type.TEXT
            )

        if success:
            with allure.step("3. 验证发布成功"):
                try:
                    self.assertTrue(self.publish.page_publish_success)
                    self.publish.page_publish_success_button_ok()
                    self.assertTrue(self.publish.page_publish_logout)
                except Exception:
                    self.publish.base_screenshot()
                    raise
        else:
            with allure.step("3. 验证错误提示"):
                msg = self.publish.page_publish_get_error_info()
                try:
                    self.assertEqual(msg, except_result)
                except AssertionError:
                    self.publish.base_screenshot()
                    raise
                finally:
                    with allure.step("清理窗口状态"):
                        cur_window = self.driver.current_window_handle
                        all_window = self.driver.window_handles
                        self.driver.close()
                        for window in all_window:
                            if window != cur_window:
                                self.driver.switch_to.window(window)