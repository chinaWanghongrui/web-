import unittest
from parameterized import parameterized
import allure  # 新增导入
from page import page_login
from page.page_login import PageLogin
from base.get_driver import GetDriver
from tools.read_json import read_json

global_error_info = 0

def get_data_login():
    datas = read_json("login.json")
    return [(d['username'], d['password'], d['success'], d['expect_result'])
            for d in datas.values()]

class Test_Login(unittest.TestCase):
    driver = None

    @classmethod
    @allure.step("初始化浏览器驱动")
    def setUpClass(cls):
        cls.driver = GetDriver().get_driver()
        cls.login = PageLogin(cls.driver)

    @classmethod
    def tearDownClass(cls):
        page_login.global_variable_login = 0
        GetDriver.quit_driver()

    @allure.title("登录测试 - {username} (预期: {'成功' if success else '失败'})")
    @allure.story("认证模块")
    @parameterized.expand(get_data_login())
    def test_login(self, username, password, success=None, expect_result=None):
        global global_error_info

        # 执行登录操作
        with allure.step(f"输入凭证: {username}/{password}"):
            self.login.page_login(username, password, self.driver)
            allure.attach(
                self.driver.get_screenshot_as_png(),
                name="登录页面截图",
                attachment_type=allure.attachment_type.PNG
            )

        if success:
            with allure.step("验证登录成功"):
                try:
                    self.assertTrue(self.login.page_is_login_success())
                    with allure.step("执行安全退出"):
                        self.login.page_click_logout()
                        self.assertTrue(self.login.page_is_logout_success())
                        global_error_info = 0
                        self.login.page_click_login()
                        self.login.page_click_pwd_login()
                except Exception as e:
                    self.login.base_screenshot()
                    raise
        else:
            with allure.step("验证错误提示"):
                msg = self.login.page_get_error_info_before()
                try:
                    self.assertEqual(msg, expect_result)
                except AssertionError:
                    self.login.base_screenshot()
                    raise

        with allure.step("清理测试环境"):
            self.driver.refresh()
            self.login.page_click_pwd_login()