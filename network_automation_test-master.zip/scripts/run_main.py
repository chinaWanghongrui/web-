import os
import pytest
from datetime import datetime

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # 获取项目根目录

if __name__ == "__main__":
    # 生成带时间戳的报告文件名
    report_name = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

    pytest.main([
        os.path.join(PROJECT_ROOT, "scripts"),  # 测试脚本目录
        f"--alluredir={os.path.join(PROJECT_ROOT, 'allure-results')}",
        "--clean-alluredir",
        f"--html={os.path.join(PROJECT_ROOT, 'result', report_name)}",  # 修复后的路径
        "--self-contained-html",
    ])