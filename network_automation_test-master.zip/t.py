# 定义链表节点类
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next


# 创建测试链表的工具函数（从列表生成链表）
def create_linked_list(arr):
    if not arr:
        return None
    head = ListNode(arr[0])
    current = head
    for val in arr[1:]:
        current.next = ListNode(val)
        current = current.next
    return head


# 打印链表的工具函数
def print_linked_list(head):
    current = head
    result = []
    while current:
        result.append(str(current.val))
        current = current.next
    print("->".join(result) + "->None")


# 待测试的Solution类
class Solution:
    def reverseBetween(self, head: ListNode, left: int, right: int) -> ListNode:
        def reverse_linked_list(head: ListNode):
            pre = None
            cur = head
            while cur:
                next_node = cur.next  # 避免与内置函数next冲突，修改变量名
                cur.next = pre
                pre = cur
                cur = next_node

        # 创建虚拟头节点
        dummy_node = ListNode(-1)
        dummy_node.next = head
        pre = dummy_node

        # 定位pre到left节点的前一个节点
        for _ in range(left - 1):
            pre = pre.next

        # 定位right_node
        right_node = pre
        for _ in range(right - left + 1):
            right_node = right_node.next

        # 切割子链表
        left_node = pre.next
        curr = right_node.next
        pre.next = None
        right_node.next = None

        # 反转子链表
        reverse_linked_list(left_node)

        # 重新连接
        pre.next = right_node
        left_node.next = curr

        return dummy_node.next


# 测试代码
if __name__ == "__main__":
    # 创建测试链表: 1->2->3->4->5->None
    test_arr = [1, 2, 3, 4, 5]
    head = create_linked_list(test_arr)

    print("原始链表:")
    print_linked_list(head)

    # 测试反转区间: left=2, right=4（预期结果: 1->4->3->2->5->None）
    solution = Solution()
    reversed_head = solution.reverseBetween(head, left=2, right=4)

    print("反转后链表:")
    print_linked_list(reversed_head)
